# YEE 式機器龍品牌素材

完整的說明和範例在 <https://yeecord.com/branding>。

## 檔案

| 檔案 | 用途 |
| --- | --- |
| `avatar.svg`、`avatar-*.png` | Discord 頭像和社群帳號。上傳整張方形圖，平台會自己裁成圓形。 |
| `avatar-staging.*`、`avatar-dev.*` | 測試環境和開發環境的頭像。 |
| `lockup.svg`、`lockup-white.svg` | 字標組合。淺色背景用深色字，深色背景用白字。字是 Baloo 2 ExtraBold 轉成的路徑。 |
| `mark.svg`、`mark-512.png` | 不帶圓框的機器龍上半身，用在貼紙、周邊這類不需要底色的地方。 |
| `character.svg`、`character-1024.png` | 透明背景的角色，放進插畫和分享圖。 |
| `sticker-320.png` | Discord 貼圖，320 × 320 px。 |
| `silhouette.svg` | 單色版本，顏色跟著周圍的文字顏色。 |
| `favicon*.svg`、`favicon*.ico`、`apple-touch-icon.png` | 網站圖示。只取頭部，16 px 也認得出來。 |
| `social-1200x630.png` | 分享連結時的預覽圖。 |
| `poses/*.png` | 機器龍的姿勢：待機、開心、跑步、跳躍、蹲下和昏倒，透明背景，1000 × 868 px。 |
| `scene/*.svg` | 首頁的村莊和小遊戲用到的場景插圖。 |

## 各環境的版本

每個環境的頭飾和背景色都不一樣。正式環境戴皇冠，測試環境戴三角錐，開發環境頭上坐一隻小黃鴨。

| 環境 | 背景 | 配件 | Discord 應用程式名稱 |
| --- | --- | --- | --- |
| production | 夜空藍 `#24375C` | 皇冠 | YEE 式機器龍 |
| staging | 測試紫 `#5E38A8` | 三角錐 | YEE 式機器龍 Staging |
| development | 開發橘 `#BA4E25` | 小黃鴨 | YEE 式機器龍 Dev |

## 顏色

| 名稱 | 色碼 | 用在 |
| --- | --- | --- |
| 夜空藍 | `#24375C` | 頭像和分享圖的背景 |
| 恐龍綠 | `#32D34C` | 角色本體 |
| 陰影綠 | `#24A63F` | 角色的陰影 |
| 皇冠金 | `#F7C157` | 皇冠 |
| 墨色 | `#362F36` | 眼睛和嘴巴 |
| 深海藍 | `#17233B` | 字標 |

## 字型

字標用的是 [Baloo 2](https://fonts.google.com/specimen/Baloo+2) ExtraBold，SIL Open Font License 1.1。

## 使用規範

- 字標組合四周至少留出頭像一半寬的空白。
- 頭像最小 16 px，字標組合最矮 24 px。再小就改用網站圖示。
- 請不要拉長、壓扁、旋轉或換顏色，也不要加外框或陰影。
- 不要放在雜亂的背景上。
- 皇冠只給正式環境戴，正式環境也不換成其他頭飾。
